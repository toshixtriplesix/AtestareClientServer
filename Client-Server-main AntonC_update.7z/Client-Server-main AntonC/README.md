# Atestare 1
 Se ruleaza intai Server, se deschide fiecare endpoint (/add/, /substract/, etc), apoi se ruleaza Client
