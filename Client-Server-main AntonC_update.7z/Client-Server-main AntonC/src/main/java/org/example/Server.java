package org.example;

import java.io.IOException;
import java.io.OutputStream;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.net.InetSocketAddress;

class ArithmeticServer {
    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        server.createContext("/add", new AddHandler());
        server.createContext("/subtract", new SubtractHandler());
        server.createContext("/multiply", new MultiplyHandler());
        server.createContext("/divide", new DivideHandler());
        server.setExecutor(null);
        server.start();
    }

    static class AddHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            double first = Double.parseDouble(exchange.getRequestHeaders().getFirst("first"));
            double second = Double.parseDouble(exchange.getRequestHeaders().getFirst("second"));
            double triple = Double.parseDouble(exchange.getRequestHeaders().getFirst("triple"));
            double result = first + second + triple;

            String response = Double.toString(result);
            exchange.sendResponseHeaders(200, response.length());
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class SubtractHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            double first = Double.parseDouble(exchange.getRequestHeaders().getFirst("first"));
            double second = Double.parseDouble(exchange.getRequestHeaders().getFirst("second"));
            double triple = Double.parseDouble(exchange.getRequestHeaders().getFirst("triple"));
            double result = first - second - triple;

            String response = Double.toString(result);
            exchange.sendResponseHeaders(200, response.length());
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class MultiplyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            double first = Double.parseDouble(exchange.getRequestHeaders().getFirst("first"));
            double second = Double.parseDouble(exchange.getRequestHeaders().getFirst("second"));
            double triple = Double.parseDouble(exchange.getRequestHeaders().getFirst("triple"));
            double result = first * second * triple;

            String response = Double.toString(result);
            exchange.sendResponseHeaders(200, response.length());
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class DivideHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            double first = Double.parseDouble(exchange.getRequestHeaders().getFirst("first"));
            double second = Double.parseDouble(exchange.getRequestHeaders().getFirst("second"));
            double triple = Double.parseDouble(exchange.getRequestHeaders().getFirst("triple"));
            double result;

            if (second != 0) {
                result = first / second / triple;
            } else {
                throw new ArithmeticException("Division by zero");
            }

            String response = Double.toString(result);
            exchange.sendResponseHeaders(200, response.length());
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }
}