package org.example;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
class ArithmeticClient {
    public static void main(String[] args) {
        double first = 5;
        double second = 5;
        double triple = 7;

        performOperation("add", first, second, triple);
        performOperation("subtract", first, second, triple);
        performOperation("multiply", first, second, triple);
        performOperation("divide", first, second, triple);
    }

    private static void performOperation(String operation, double first, double second ,double triple) {
        try {
            URL operationUrl = new URL("http://localhost:8080/" + operation);
            HttpURLConnection connection = (HttpURLConnection) operationUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("first", String.valueOf(first));
            connection.setRequestProperty("second", String.valueOf(second));
            connection.setRequestProperty("triple", String.valueOf(triple));

            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String result = reader.readLine();
                System.out.println("Success for " + operation + ": " + result);
            } else {
                BufferedReader errorReader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                String errorMessage = errorReader.readLine();
                System.out.println("Fail for " + operation + ": " + responseCode);
                System.out.println(errorMessage);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}